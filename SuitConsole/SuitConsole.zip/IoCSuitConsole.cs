﻿using Suit;
using $safeprojectname$.Tools;
using Unity;

namespace $safeprojectname$
{
	public static class IoCSuitConsole
	{
        public static void Register(UnityContainer container)
        {
            container.RegisterSingleton<Settings>();
            container.RegisterFactory<IMyToolSettings>(c => IoC.Get<Settings>());
        }
    }
}