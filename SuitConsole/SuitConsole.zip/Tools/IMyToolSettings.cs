﻿namespace $safeprojectname$.Tools
{
    public interface IMyToolSettings
    {
        
    }
}