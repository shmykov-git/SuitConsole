﻿using Suit.Logs;

namespace $safeprojectname$.Tools
{
    class MyTool
    {
        public MyTool(ILog log, IMyToolSettings settings)
        {
            
        }

        public void Start()
        {

        }
    }
}
